"""ABA common tools."""
